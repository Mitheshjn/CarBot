import network
import socket
import select
import time
import math
import struct
import random
import framebuf
import machine
import esp
from machine import Pin, PWM, SoftI2C

# ================= HARDWARE CLOCK & OS =================
try:
    machine.freq(160000000)
    esp.osdebug(None)
except Exception:
    pass

# ================= ANTI-BRICK SAFE BOOT =================
try:
    with open("executable.py", "w") as f:
        f.write("")
    print("executable.py reset to factory empty state.")
except Exception as e:
    print("executable.py init notice:", e)

custom_script_active = False
script_pending_start = False

# ================= PINS CONFIGURATION =================
IN1_PIN = 0
IN2_PIN = 1
IN3_PIN = 3
IN4_PIN = 4
FRONT_LED_PIN = 6
BACK_LED_PIN = 7

PORT_SCL_PIN = 5
PORT_SDA_PIN = 10
PORT_DETECT_PIN = 20

# ================= MOTOR & PWM SETUP =================
pwm_in1 = PWM(Pin(IN1_PIN), freq=1000, duty_u16=0)
pwm_in2 = PWM(Pin(IN2_PIN), freq=1000, duty_u16=0)
pwm_in3 = PWM(Pin(IN3_PIN), freq=1000, duty_u16=0)
pwm_in4 = PWM(Pin(IN4_PIN), freq=1000, duty_u16=0)

front_led = Pin(FRONT_LED_PIN, Pin.OUT, value=0)
back_led = Pin(BACK_LED_PIN, Pin.OUT, value=0)
port_detect = Pin(PORT_DETECT_PIN, Pin.IN, Pin.PULL_UP)

# Global Drive States
DIR_STOP, DIR_FWD, DIR_BACK, DIR_LEFT, DIR_RIGHT = 0, 1, 2, 3, 4
current_dir = DIR_STOP
current_speed_pwm = 0
front_led_on = False
reverse_active = False
stop_held = False
last_drive_time = time.ticks_ms()
DRIVE_WATCHDOG_MS = 600

# Protected Kickstart State Machine
kick_timer_end = 0
kick_a, kick_b, kick_c, kick_d = 0, 0, 0, 0

# Modular Accel Telemetry
mod_accel_type = None
mod_accel_addr = None
mod_accel_present = False
mod_pitch, mod_roll, mod_tilt = 0.0, 0.0, 0.0
mod_ax, mod_ay, mod_az = 0.0, 0.0, 9.8

# Modular Sensor Telemetry
latest_dist_mm = -1
latest_temp = 0.0
latest_humidity = 0.0
ldr_is_dark = False
latest_reading = "Safe Mode (Idle)"
oled_mode = 0

# Animated Face State
face_blink_timer = time.ticks_ms()
face_blinking = False

# ================= EMBEDDED SSD1306 DRIVER =================
class SSD1306_I2C(framebuf.FrameBuffer):
    def __init__(self, width, height, i2c, addr=0x3C):
        self.width = width
        self.height = height
        self.i2c = i2c
        self.addr = addr
        self.buffer = bytearray((self.height // 8) * self.width)
        super().__init__(self.buffer, self.width, self.height, framebuf.MONO_VLSB)
        self.init_display()

    def write_cmd(self, cmd):
        self.i2c.writeto(self.addr, bytearray([0x80, cmd]))

    def init_display(self):
        for cmd in (
            0xAE, 0xD5, 0x80, 0xA8, self.height - 1, 0xD3, 0x00, 0x40,
            0x8D, 0x14, 0x20, 0x00, 0xA1, 0xC8, 0xDA, 0x12 if self.height == 64 else 0x02,
            0x81, 0xCF, 0xD9, 0xF1, 0xDB, 0x40, 0xA4, 0xA6, 0xAF
        ):
            self.write_cmd(cmd)
        self.fill(0)
        self.show()

    def show(self):
        self.write_cmd(0x21)
        self.write_cmd(0)
        self.write_cmd(self.width - 1)
        self.write_cmd(0x22)
        self.write_cmd(0)
        self.write_cmd((self.height // 8) - 1)
        self.i2c.writeto(self.addr, b'\x40' + self.buffer)

# ================= EMBEDDED VL53L0X DRIVER =================
class VL53L0X:
    def __init__(self, i2c, address=0x29):
        self.i2c = i2c
        self.address = address
        self.init_sensor()

    def _write_reg(self, reg, val):
        self.i2c.writeto_mem(self.address, reg, bytes([val]))

    def _read_reg(self, reg):
        return self.i2c.readfrom_mem(self.address, reg, 1)[0]

    def init_sensor(self):
        self._write_reg(0x88, 0x00)
        self._write_reg(0x80, 0x01)
        self._write_reg(0xFF, 0x01)
        self._write_reg(0x00, 0x00)
        self._read_reg(0x91)
        self._write_reg(0x00, 0x01)
        self._write_reg(0xFF, 0x00)
        self._write_reg(0x80, 0x00)
        self._write_reg(0x00, 0x02)

    def read_range(self):
        try:
            val = self.i2c.readfrom_mem(self.address, 0x14 + 10, 2)
            dist = (val[0] << 8) | val[1]
            if dist == 0 or dist == 0xFFFF or dist > 8190:
                return -1
            return dist
        except Exception:
            return -1

# ================= MODULAR PORT CONTROLLER =================
MODE_IDLE, MODE_DISTANCE, MODE_DHT11, MODE_DHT22, MODE_LDR, MODE_RGB, MODE_OLED, MODE_ACCEL, MODE_SERVO = range(9)
current_port_mode = MODE_IDLE

port_i2c = None
port_oled = None
port_vl53 = None
port_np = None
port_dht = None
port_servo_pwm = None
port_ldr_pin = None
current_servo_angle = 90
was_connected = False
last_port_read_time = time.ticks_ms()

# RGB Ring parameters
rgb_mode = "off"
rgb_brightness = 80
rgb_custom = (0, 122, 255)
rgb_step = 0
breath_val = 0
breath_dir = 1
police_toggle = False
chase_pos = 0
turn_indicator_pos = 0
last_rgb_update = time.ticks_ms()

def set_modular_port_idle():
    global current_port_mode, port_i2c, port_oled, port_vl53, port_np
    global port_dht, port_servo_pwm, port_ldr_pin, mod_accel_present, mod_accel_type, mod_accel_addr
    global latest_reading, latest_dist_mm

    if port_oled:
        try: port_oled.fill(0); port_oled.show()
        except Exception: pass
        port_oled = None

    if port_np:
        try:
            for i in range(8): port_np[i] = (0, 0, 0)
            port_np.write()
        except Exception: pass
        port_np = None

    if port_servo_pwm:
        port_servo_pwm.deinit()
        port_servo_pwm = None

    port_i2c = None
    port_vl53 = None
    port_dht = None
    port_ldr_pin = None
    mod_accel_present = False
    mod_accel_type = None
    mod_accel_addr = None

    Pin(PORT_SCL_PIN, Pin.IN)
    Pin(PORT_SDA_PIN, Pin.IN)

    current_port_mode = MODE_IDLE
    stop_motors()
    latest_dist_mm = -1
    latest_reading = "Safe Mode (Idle)"

def activate_distance():
    global current_port_mode, port_i2c, port_vl53, latest_reading
    set_modular_port_idle()
    try:
        port_i2c = SoftI2C(scl=Pin(PORT_SCL_PIN), sda=Pin(PORT_SDA_PIN), freq=100000)
        port_vl53 = VL53L0X(port_i2c)
        current_port_mode = MODE_DISTANCE
        latest_reading = "Measuring..."
    except Exception as e:
        set_modular_port_idle()
        latest_reading = f"Error: VL53L0X ({e})"

def activate_dht11():
    global current_port_mode, port_dht, latest_reading
    set_modular_port_idle()
    import dht
    port_dht = dht.DHT11(Pin(PORT_SCL_PIN))
    current_port_mode = MODE_DHT11
    latest_reading = "Reading DHT11..."

def activate_dht22():
    global current_port_mode, port_dht, latest_reading
    set_modular_port_idle()
    import dht
    port_dht = dht.DHT22(Pin(PORT_SCL_PIN))
    current_port_mode = MODE_DHT22
    latest_reading = "Reading DHT22..."

def activate_ldr():
    global current_port_mode, port_ldr_pin, latest_reading
    set_modular_port_idle()
    port_ldr_pin = Pin(PORT_SCL_PIN, Pin.IN, Pin.PULL_UP)
    current_port_mode = MODE_LDR
    latest_reading = "Reading LDR..."

def activate_rgb():
    global current_port_mode, port_np, latest_reading
    set_modular_port_idle()
    import neopixel
    port_np = neopixel.NeoPixel(Pin(PORT_SCL_PIN), 8)
    current_port_mode = MODE_RGB
    latest_reading = "RGB Ring Active"

def activate_oled():
    global current_port_mode, port_i2c, port_oled, latest_reading
    set_modular_port_idle()
    try:
        port_i2c = SoftI2C(scl=Pin(PORT_SCL_PIN), sda=Pin(PORT_SDA_PIN), freq=400000)
        port_oled = SSD1306_I2C(128, 64, port_i2c, addr=0x3C)
        current_port_mode = MODE_OLED
        latest_reading = "OLED Online"
    except Exception as e:
        set_modular_port_idle()
        latest_reading = f"Error: OLED ({e})"

def activate_accel():
    global current_port_mode, port_i2c, mod_accel_present, mod_accel_type, mod_accel_addr, latest_reading
    set_modular_port_idle()
    try:
        port_i2c = SoftI2C(scl=Pin(PORT_SCL_PIN), sda=Pin(PORT_SDA_PIN), freq=100000)
        devs = port_i2c.scan()
        if 0x53 in devs:
            port_i2c.writeto_mem(0x53, 0x2D, b'\x08')
            mod_accel_type = "ADXL345"
            mod_accel_addr = 0x53
            mod_accel_present = True
        elif 0x68 in devs or 0x69 in devs:
            mod_accel_addr = 0x68 if 0x68 in devs else 0x69
            port_i2c.writeto_mem(mod_accel_addr, 0x6B, b'\x00')
            mod_accel_type = f"MPU-6050 ({hex(mod_accel_addr)})"
            mod_accel_present = True
        else:
            raise Exception("No sensor found (scan empty)")
        current_port_mode = MODE_ACCEL
        latest_reading = f"{mod_accel_type} Online"
    except Exception as e:
        set_modular_port_idle()
        latest_reading = f"Error: Accel ({e})"

def activate_servo():
    global current_port_mode, port_servo_pwm, current_servo_angle, latest_reading
    set_modular_port_idle()
    port_servo_pwm = PWM(Pin(PORT_SCL_PIN), freq=50)
    set_servo_angle(90)
    current_port_mode = MODE_SERVO
    latest_reading = "Servo: 90 deg"

def set_servo_angle(angle):
    global current_servo_angle
    if port_servo_pwm:
        current_servo_angle = max(0, min(180, int(angle)))
        us = 500 + int((current_servo_angle / 180.0) * 1900)
        duty = int((us / 20000.0) * 65535)
        port_servo_pwm.duty_u16(duty)

# ================= ANIMATED ROBOT FACE =================
def draw_animated_face():
    global face_blink_timer, face_blinking
    if not port_oled:
        return
    now = time.ticks_ms()

    if not face_blinking and time.ticks_diff(now, face_blink_timer) > 3500:
        face_blinking = True
        face_blink_timer = now
    elif face_blinking and time.ticks_diff(now, face_blink_timer) > 140:
        face_blinking = False
        face_blink_timer = now

    dx, dy = 0, 0
    if current_dir == DIR_FWD: dy = -4
    elif current_dir == DIR_BACK: dy = 4
    elif current_dir == DIR_LEFT: dx = -5
    elif current_dir == DIR_RIGHT: dx = 5

    if face_blinking:
        port_oled.fill_rect(24, 28, 28, 4, 1)
        port_oled.fill_rect(76, 28, 28, 4, 1)
    else:
        port_oled.fill_rect(24, 16, 28, 26, 1)
        port_oled.fill_rect(76, 16, 28, 26, 1)
        port_oled.fill_rect(32 + dx, 22 + dy, 12, 14, 0)
        port_oled.fill_rect(84 + dx, 22 + dy, 12, 14, 0)

    if current_dir == DIR_FWD:
        port_oled.line(54, 52, 64, 56, 1)
        port_oled.line(64, 56, 74, 52, 1)
    elif current_dir == DIR_BACK:
        port_oled.rect(56, 50, 16, 6, 1)
    else:
        port_oled.line(54, 52, 74, 52, 1)

# ================= CHROME DINO (VISIBLE SPRITES) =================
DINO_GROUND = 42
dino_y = float(DINO_GROUND)
dino_vel_y = 0.0
dino_ducking = False
dino_game_over = False
dino_score = 0
dino_obs_x = 130
dino_obs_type = 0

def dino_jump():
    global dino_game_over, dino_score, dino_obs_x, dino_y, dino_vel_y, dino_ducking
    if dino_game_over:
        dino_game_over = False; dino_score = 0; dino_obs_x = 130; dino_y = float(DINO_GROUND); dino_vel_y = 0.0; dino_ducking = False; return
    if dino_y >= DINO_GROUND: dino_vel_y = -6.8

def dino_crouch(duck):
    global dino_ducking
    dino_ducking = duck

def draw_dino():
    global dino_y, dino_vel_y, dino_obs_x, dino_obs_type, dino_score, dino_game_over
    if not port_oled: return
    if not dino_game_over:
        dino_y += dino_vel_y; dino_vel_y += 0.9
        if dino_y >= DINO_GROUND: dino_y = float(DINO_GROUND); dino_vel_y = 0.0
        dino_obs_x -= 4
        if dino_obs_x < -16:
            dino_obs_x = 128 + random.randint(10, 45); dino_obs_type = random.randint(0, 1); dino_score += 1

        dino_w = 14 if dino_ducking else 10
        dino_h = 8 if dino_ducking else 14
        dino_box_y = 48 if dino_ducking else int(dino_y)

        if dino_obs_type == 0:
            if (dino_obs_x < (16 + dino_w)) and ((dino_obs_x + 8) > 16) and ((dino_box_y + dino_h) > 44): dino_game_over = True
        else:
            if (dino_obs_x < (16 + dino_w)) and ((dino_obs_x + 12) > 16) and (not dino_ducking or dino_y < DINO_GROUND): dino_game_over = True

    port_oled.line(0, 56, 127, 56, 1)

    if dino_ducking and dino_y >= DINO_GROUND:
        port_oled.fill_rect(14, 49, 12, 6, 1)
        port_oled.fill_rect(24, 47, 4, 4, 1)
    else:
        dy = int(dino_y)
        port_oled.fill_rect(18, dy, 6, 5, 1)
        port_oled.fill_rect(16, dy + 4, 6, 8, 1)
        port_oled.pixel(22, dy + 1, 0)

    if dino_obs_x > -16 and dino_obs_x < 128:
        if dino_obs_type == 0:
            port_oled.fill_rect(dino_obs_x + 2, 44, 4, 12, 1)
            port_oled.fill_rect(dino_obs_x, 47, 3, 5, 1)
            port_oled.fill_rect(dino_obs_x + 5, 46, 3, 5, 1)
        else:
            port_oled.fill_rect(dino_obs_x, 34, 10, 4, 1)
            port_oled.line(dino_obs_x + 2, 32, dino_obs_x + 7, 32, 1)

    port_oled.text("DINO", 0, 0, 1)
    port_oled.text(f"SC:{dino_score}", 75, 0, 1)
    if dino_game_over:
        port_oled.fill_rect(18, 16, 92, 24, 0)
        port_oled.rect(18, 16, 92, 24, 1)
        port_oled.text("GAME OVER", 26, 24, 1)

# ================= SPACE INVADERS (VISIBLE ALIENS) =================
invader_ship_x = 58
invader_move_dir = 0
invader_laser_active = False
invader_laser_x, invader_laser_y = 0, 0
alien_alive = [True] * 10
alien_fleet_x, alien_fleet_y = 14, 12
alien_fleet_dir = 1
invader_score = 0
invader_game_over = False
last_alien_step = time.ticks_ms()

def init_invaders():
    global invader_ship_x, invader_move_dir, invader_laser_active, alien_fleet_x, alien_fleet_y, alien_fleet_dir, invader_score, invader_game_over, alien_alive
    invader_ship_x = 58; invader_move_dir = 0; invader_laser_active = False; alien_fleet_x = 14; alien_fleet_y = 12; alien_fleet_dir = 1; invader_score = 0; invader_game_over = False; alien_alive = [True] * 10

def invader_fire():
    global invader_laser_active, invader_laser_x, invader_laser_y
    if invader_game_over: init_invaders(); return
    if not invader_laser_active: invader_laser_active = True; invader_laser_x = invader_ship_x + 5; invader_laser_y = 50

def draw_invaders():
    global invader_ship_x, invader_laser_active, invader_laser_y, last_alien_step, alien_fleet_x, alien_fleet_y, alien_fleet_dir, invader_score, invader_game_over
    if not port_oled: return
    invader_ship_x = max(2, min(114, invader_ship_x + invader_move_dir * 3))

    if invader_laser_active:
        invader_laser_y -= 5
        if invader_laser_y < 4: invader_laser_active = False

    now = time.ticks_ms()
    if not invader_game_over and time.ticks_diff(now, last_alien_step) > 110:
        last_alien_step = now
        alien_fleet_x += alien_fleet_dir * 3
        if alien_fleet_x > 45 or alien_fleet_x < 6:
            alien_fleet_dir = -alien_fleet_dir
            alien_fleet_y += 3

    for row in range(2):
        for col in range(5):
            idx = row * 5 + col
            if alien_alive[idx]:
                ax = alien_fleet_x + col * 14
                ay = alien_fleet_y + row * 9
                if (invader_laser_active and invader_laser_x >= ax and invader_laser_x <= ax + 9 and invader_laser_y >= ay and invader_laser_y <= ay + 7):
                    alien_alive[idx] = False
                    invader_laser_active = False
                    invader_score += 10
                if ay + 7 >= 52:
                    invader_game_over = True

                port_oled.fill_rect(ax + 1, ay, 6, 6, 1)
                port_oled.pixel(ax, ay + 2, 1)
                port_oled.pixel(ax + 7, ay + 2, 1)
                port_oled.pixel(ax + 2, ay + 2, 0)
                port_oled.pixel(ax + 5, ay + 2, 0)

    port_oled.text("INVADERS", 0, 0, 1)
    port_oled.text(f"SC:{invader_score}", 75, 0, 1)
    if invader_laser_active:
        port_oled.line(invader_laser_x, invader_laser_y, invader_laser_x, invader_laser_y + 4, 1)
    port_oled.fill_rect(invader_ship_x, 56, 12, 4, 1)

# ================= OLED SCREEN REFRESH =================
last_oled_update = time.ticks_ms()

def update_oled():
    global last_oled_update
    if not port_oled or current_port_mode != MODE_OLED:
        return
    frame_interval = 35 if (oled_mode in (3, 5)) else 80
    now = time.ticks_ms()
    if time.ticks_diff(now, last_oled_update) < frame_interval:
        return
    last_oled_update = now

    port_oled.fill(0)
    if oled_mode == 5:
        draw_invaders()
    elif oled_mode == 3:
        draw_dino()
    else:
        draw_animated_face()
    port_oled.show()

# ================= RGB RING CONTROLLER =================
def set_all_rgb(r, g, b):
    if not port_np:
        return
    scale = rgb_brightness / 255.0
    color = (int(r * scale), int(g * scale), int(b * scale))
    for i in range(8):
        port_np[i] = color
    port_np.write()

def update_rgb():
    global last_rgb_update, rgb_step, breath_val, breath_dir, police_toggle, chase_pos, turn_indicator_pos
    if current_port_mode != MODE_RGB or not port_np:
        return
    now = time.ticks_ms()

    if rgb_mode == "off":
        for i in range(8): port_np[i] = (0, 0, 0)
        port_np.write()
    elif rgb_mode == "custom":
        set_all_rgb(*rgb_custom)
    elif rgb_mode == "red":
        set_all_rgb(255, 0, 0)
    elif rgb_mode == "green":
        set_all_rgb(0, 255, 0)
    elif rgb_mode == "blue":
        set_all_rgb(0, 0, 255)
    elif rgb_mode == "auto":
        # AUTO MODE: White forward, Red reverse/stop, Circulating Yellow Amber indicators for Left & Right!
        if current_dir == DIR_FWD:
            set_all_rgb(180, 180, 180)
        elif current_dir == DIR_BACK:
            set_all_rgb(255, 0, 0)
        elif current_dir == DIR_LEFT:
            if time.ticks_diff(now, last_rgb_update) > 75:
                last_rgb_update = now
                turn_indicator_pos = (turn_indicator_pos - 1) % 8
                scale = rgb_brightness / 255.0
                for i in range(8):
                    if i == turn_indicator_pos:
                        port_np[i] = (int(255 * scale), int(150 * scale), 0)
                    elif i == (turn_indicator_pos + 1) % 8:
                        port_np[i] = (int(80 * scale), int(40 * scale), 0)
                    else:
                        port_np[i] = (0, 0, 0)
                port_np.write()
        elif current_dir == DIR_RIGHT:
            if time.ticks_diff(now, last_rgb_update) > 75:
                last_rgb_update = now
                turn_indicator_pos = (turn_indicator_pos + 1) % 8
                scale = rgb_brightness / 255.0
                for i in range(8):
                    if i == turn_indicator_pos:
                        port_np[i] = (int(255 * scale), int(150 * scale), 0)
                    elif i == (turn_indicator_pos - 1) % 8:
                        port_np[i] = (int(80 * scale), int(40 * scale), 0)
                    else:
                        port_np[i] = (0, 0, 0)
                port_np.write()
        elif current_dir == DIR_STOP:
            if stop_held:
                set_all_rgb(255, 0, 0)
            else:
                set_all_rgb(20, 20, 20)
    elif rgb_mode == "tacho":
        lit = int((current_speed_pwm / 255.0) * 8)
        if current_speed_pwm > 8 and lit == 0: lit = 1
        scale = rgb_brightness / 255.0
        for i in range(8):
            if i < lit:
                if i < 3: port_np[i] = (0, int(255 * scale), 0)
                elif i < 6: port_np[i] = (int(255 * scale), int(140 * scale), 0)
                else: port_np[i] = (int(255 * scale), 0, 0)
            else:
                port_np[i] = (0, 0, 0)
        port_np.write()
    elif rgb_mode == "breathing":
        if time.ticks_diff(now, last_rgb_update) > 15:
            last_rgb_update = now
            breath_val += breath_dir * 4
            if breath_val >= 180: breath_val = 180; breath_dir = -1
            elif breath_val <= 5: breath_val = 5; breath_dir = 1
            set_all_rgb(breath_val, breath_val, breath_val)
    elif rgb_mode == "police":
        if time.ticks_diff(now, last_rgb_update) > 120:
            last_rgb_update = now; police_toggle = not police_toggle
            scale = rgb_brightness / 255.0
            c1 = (int(255 * scale), 0, 0) if police_toggle else (0, 0, int(255 * scale))
            c2 = (0, 0, int(255 * scale)) if police_toggle else (int(255 * scale), 0, 0)
            for i in range(4): port_np[i] = c1
            for i in range(4, 8): port_np[i] = c2
            port_np.write()
    elif rgb_mode == "chase":
        if time.ticks_diff(now, last_rgb_update) > 65:
            last_rgb_update = now
            chase_pos = (chase_pos + 1) % 8
            scale = rgb_brightness / 255.0
            for i in range(8):
                diff = (i - chase_pos) % 8
                if diff == 0:
                    port_np[i] = (0, int(230 * scale), int(255 * scale))
                elif diff == 7:
                    port_np[i] = (0, int(90 * scale), int(160 * scale))
                elif diff == 6:
                    port_np[i] = (0, int(25 * scale), int(60 * scale))
                else:
                    port_np[i] = (0, 0, 0)
            port_np.write()
    elif rgb_mode == "rainbow":
        if time.ticks_diff(now, last_rgb_update) > 30:
            last_rgb_update = now
            rgb_step = (rgb_step + 8) % 256
            for i in range(8):
                pos = (i * 32 + rgb_step) % 256
                if pos < 85: c = (pos * 3, 255 - pos * 3, 0)
                elif pos < 170: pos -= 85; c = (255 - pos * 3, 0, pos * 3)
                else: pos -= 170; c = (0, pos * 3, 255 - pos * 3)
                scale = rgb_brightness / 255.0
                port_np[i] = (int(c[0] * scale), int(c[1] * scale), int(c[2] * scale))
            port_np.write()

# ================= PROTECTED MOTOR KICKSTART CONTROLLER =================
def is_dino_mode(): return current_port_mode == MODE_OLED and oled_mode == 3
def is_invaders_mode(): return current_port_mode == MODE_OLED and oled_mode == 5

def set_motors(a, b, c, d, direction, reverse):
    global current_dir, reverse_active, kick_timer_end, kick_a, kick_b, kick_c, kick_d
    if current_speed_pwm == 0 or direction == DIR_STOP:
        pwm_in1.duty_u16(0); pwm_in2.duty_u16(0); pwm_in3.duty_u16(0); pwm_in4.duty_u16(0)
        current_dir = DIR_STOP; reverse_active = False
        kick_timer_end = 0
        return

    now = time.ticks_ms()

    # PROTECTED KICKSTART BURST (110ms):
    # If the burst is currently active, do NOT let rapid repeat packets overwrite the full power!
    if kick_timer_end != 0 and time.ticks_diff(now, kick_timer_end) < 0:
        current_dir = direction
        reverse_active = reverse
        return

    # Trigger kickstart on starting from STOP, OR on direction change (crucial for Cockpit steering!)
    if (current_dir == DIR_STOP or current_dir != direction) and current_speed_pwm < 240:
        kick_timer_end = time.ticks_add(now, 110)
        kick_a, kick_b, kick_c, kick_d = a, b, c, d
        pwm_in1.duty_u16(65535 if a else 0)
        pwm_in2.duty_u16(65535 if b else 0)
        pwm_in3.duty_u16(65535 if c else 0)
        pwm_in4.duty_u16(65535 if d else 0)
        current_dir = direction
        reverse_active = reverse
        return

    # Settle into configured target speed
    duty = int((current_speed_pwm / 255.0) * 65535)
    pwm_in1.duty_u16(duty if a else 0)
    pwm_in2.duty_u16(duty if b else 0)
    pwm_in3.duty_u16(duty if c else 0)
    pwm_in4.duty_u16(duty if d else 0)
    current_dir = direction
    reverse_active = reverse

def check_kickstart_expiry(now):
    global kick_timer_end
    if kick_timer_end != 0 and time.ticks_diff(now, kick_timer_end) >= 0:
        kick_timer_end = 0
        if current_dir != DIR_STOP:
            duty = int((current_speed_pwm / 255.0) * 65535)
            pwm_in1.duty_u16(duty if kick_a else 0)
            pwm_in2.duty_u16(duty if kick_b else 0)
            pwm_in3.duty_u16(duty if kick_c else 0)
            pwm_in4.duty_u16(duty if kick_d else 0)

def stop_motors():
    global kick_timer_end
    kick_timer_end = 0
    set_motors(0, 0, 0, 0, DIR_STOP, False)

def move_forward():
    if is_dino_mode(): dino_jump(); return
    if is_invaders_mode(): invader_fire(); return
    set_motors(1, 0, 1, 0, DIR_FWD, False)

def move_backward():
    if is_dino_mode(): dino_crouch(True); return
    set_motors(0, 1, 0, 1, DIR_BACK, True)

def turn_left():
    global invader_move_dir
    if is_invaders_mode(): invader_move_dir = -1; return
    set_motors(0, 1, 1, 0, DIR_LEFT, False)

def turn_right():
    global invader_move_dir
    if is_invaders_mode(): invader_move_dir = 1; return
    set_motors(1, 0, 0, 1, DIR_RIGHT, False)

# ================= MODULAR SENSOR POLLING ROUTINE =================
def poll_modular_sensors(now):
    global latest_dist_mm, latest_reading, last_port_read_time, latest_temp, latest_humidity
    global ldr_is_dark, mod_ax, mod_ay, mod_az, mod_pitch, mod_roll, mod_tilt, was_connected

    is_connected = (port_detect.value() == 0)
    if not is_connected and was_connected:
        was_connected = False
        set_modular_port_idle()
    if is_connected and not was_connected:
        was_connected = True
        latest_reading = "Module connected. Select mode."

    if not is_connected:
        return

    # 1. Distance VL53L0X
    if current_port_mode == MODE_DISTANCE and port_vl53:
        if time.ticks_diff(now, last_port_read_time) >= 60:
            last_port_read_time = now
            dist = port_vl53.read_range()
            latest_dist_mm = dist
            ok = (dist != -1)
            latest_reading = f"{dist} mm ({dist/10.0:.1f} cm)" if ok else "Out of range"

    # 2. DHT11 / DHT22
    elif current_port_mode in (MODE_DHT11, MODE_DHT22) and port_dht:
        if time.ticks_diff(now, last_port_read_time) >= 1000:
            last_port_read_time = now
            try:
                port_dht.measure()
                latest_temp = port_dht.temperature()
                latest_humidity = port_dht.humidity()
                latest_reading = f"{latest_temp:.1f} C | {latest_humidity:.0f} %"
            except Exception:
                pass

    # 3. LDR Light Sensor
    elif current_port_mode == MODE_LDR and port_ldr_pin:
        if time.ticks_diff(now, last_port_read_time) >= 60:
            last_port_read_time = now
            ldr_is_dark = (port_ldr_pin.value() == 1)
            latest_reading = "DARK DETECTED" if ldr_is_dark else "LIGHT DETECTED"

    # 4. Modular Accel Auto-Reader
    elif current_port_mode == MODE_ACCEL and mod_accel_present and port_i2c:
        if time.ticks_diff(now, last_port_read_time) >= 60:
            last_port_read_time = now
            try:
                if mod_accel_type == "ADXL345":
                    raw = port_i2c.readfrom_mem(0x53, 0x32, 6)
                    rx, ry, rz = struct.unpack('<hhh', raw)
                    mod_ax = rx * 0.0383
                    mod_ay = ry * 0.0383
                    mod_az = rz * 0.0383
                else:
                    raw = port_i2c.readfrom_mem(mod_accel_addr, 0x3B, 6)
                    rx, ry, rz = struct.unpack('>hhh', raw)
                    mod_ax = rx * 0.00586
                    mod_ay = ry * 0.00586
                    mod_az = rz * 0.00586

                mod_pitch = math.degrees(math.atan2(mod_ay, math.sqrt(mod_ax * mod_ax + mod_az * mod_az)))
                mod_roll = math.degrees(math.atan2(-mod_ax, mod_az))
                mod_tilt = math.degrees(math.atan2(math.sqrt(mod_ax * mod_ax + mod_ay * mod_ay), abs(mod_az) + 0.001))
                latest_reading = f"P:{mod_pitch:.0f} R:{mod_roll:.0f} T:{mod_tilt:.0f}"
            except Exception:
                latest_reading = "Reading error"

# ================= BACKGROUND SERVICE HUB =================
def service_background_tasks():
    now = time.ticks_ms()
    poll_dns()
    handle_http()
    check_kickstart_expiry(now)
    update_rgb()
    update_oled()
    poll_modular_sensors(now)

# ================= CUSTOM EXECUTABLE RUNNER =================
class StopScriptException(Exception):
    pass

def custom_wait(ms):
    global custom_script_active, last_drive_time
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < ms:
        last_drive_time = time.ticks_ms()
        service_background_tasks()
        if not custom_script_active:
            raise StopScriptException()
        time.sleep_ms(3)

def set_custom_speed(pwm_val):
    global current_speed_pwm
    current_speed_pwm = max(0, min(255, int(pwm_val)))

def run_custom_executable():
    global custom_script_active, last_drive_time
    custom_script_active = True
    last_drive_time = time.ticks_ms()
    try:
        env = globals().copy()
        env['wait'] = custom_wait
        env['forward'] = move_forward
        env['backward'] = move_backward
        env['left'] = turn_left
        env['right'] = turn_right
        env['stop'] = stop_motors
        env['set_speed'] = set_custom_speed
        env['get_dist'] = lambda: latest_dist_mm
        env['get_temp'] = lambda: latest_temp
        env['get_humidity'] = lambda: latest_humidity
        env['is_dark'] = lambda: ldr_is_dark
        env['set_servo'] = set_servo_angle
        env['set_rgb'] = set_all_rgb

        with open("executable.py", "r") as f:
            code_str = f.read()

        if code_str.strip():
            print("Executing custom block logic from executable.py...")
            exec(code_str, env)
    except StopScriptException:
        print("Script stopped by user command.")
    except Exception as e:
        print("Error executing custom script:", e)
    finally:
        stop_motors()
        custom_script_active = False

# ================= BALANCED WI-FI AP =================
ap = network.WLAN(network.AP_IF)
ap.active(True)
ap.config(essid="SNAP-RACER", password="12345678", authmode=network.AUTH_WPA_WPA2_PSK)
ap.ifconfig(('192.168.4.1', '255.255.255.0', '192.168.4.1', '192.168.4.1'))

dns_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
dns_socket.setblocking(False)
dns_socket.bind(('192.168.4.1', 53))

http_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
http_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
http_socket.setblocking(False)
http_socket.bind(('0.0.0.0', 80))
http_socket.listen(5)

def poll_dns():
    try:
        data, addr = dns_socket.recvfrom(512)
        if data:
            packet = bytearray(data[:2]) + b'\x81\x80'
            packet += data[4:6] + data[4:6] + b'\x00\x00\x00\x00' + data[12:]
            packet += b'\xc0\x0c\x00\x01\x00\x01\x00\x00\x00\x3c\x00\x04\xc0\xa8\x04\x01'
            dns_socket.sendto(packet, addr)
    except Exception:
        pass

def parse_query(qs):
    params = {}
    if not qs:
        return params
    for part in qs.split('&'):
        if '=' in part:
            k, v = part.split('=', 1)
            params[k] = v
    return params

def handle_http():
    global current_speed_pwm, last_drive_time, front_led_on
    global oled_mode, rgb_mode, rgb_custom, rgb_brightness
    global stop_held, invader_move_dir, custom_script_active, script_pending_start

    try:
        cl, _ = http_socket.accept()
    except Exception:
        return

    try:
        cl.settimeout(0.015)
        req = cl.recv(2048).decode('utf-8', 'ignore')
        if not req:
            cl.close()
            return

        lines = req.split('\r\n')
        req_line = lines[0].split(' ')
        if len(req_line) < 2:
            cl.close()
            return

        method, full_path = req_line[0], req_line[1]
        path, _, qs = full_path.partition('?')
        params = parse_query(qs)

        cors = "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: *\r\n"

        if path == "/uploadCode":
            body = ""
            if '\r\n\r\n' in req:
                body = req.split('\r\n\r\n', 1)[1]
            elif '\n\n' in req:
                body = req.split('\n\n', 1)[1]
            try:
                with open("executable.py", "w") as f:
                    f.write(body)
                cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nCode Saved")
                cl.close()
                script_pending_start = True
                return
            except Exception as e:
                cl.send(f"HTTP/1.1 500 Error\r\n{cors}Content-Type: text/plain\r\n\r\n{e}")
                cl.close()
                return

        elif path == "/stopCode":
            custom_script_active = False
            stop_motors()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nStopped")
        elif path == "/forward":
            last_drive_time = time.ticks_ms()
            move_forward()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/backward":
            last_drive_time = time.ticks_ms()
            move_backward()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/left":
            last_drive_time = time.ticks_ms()
            turn_left()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/right":
            last_drive_time = time.ticks_ms()
            turn_right()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/stop":
            last_drive_time = time.ticks_ms()
            if is_dino_mode(): dino_crouch(False)
            if is_invaders_mode(): invader_move_dir = 0
            stop_motors()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/stopStart":
            stop_held = True
            stop_motors()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/stopEnd":
            stop_held = False
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/ping":
            if current_dir != DIR_STOP:
                last_drive_time = time.ticks_ms()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setSpeed":
            if "pwm" in params:
                current_speed_pwm = max(0, min(255, int(params["pwm"])))
                if current_speed_pwm == 0:
                    stop_motors()
                elif current_dir != DIR_STOP:
                    duty = int((current_speed_pwm / 255.0) * 65535)
                    a = current_dir in (DIR_FWD, DIR_RIGHT)
                    b = current_dir in (DIR_BACK, DIR_LEFT)
                    c = current_dir in (DIR_FWD, DIR_LEFT)
                    d = current_dir in (DIR_BACK, DIR_RIGHT)
                    pwm_in1.duty_u16(duty if a else 0)
                    pwm_in2.duty_u16(duty if b else 0)
                    pwm_in3.duty_u16(duty if c else 0)
                    pwm_in4.duty_u16(duty if d else 0)
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setFrontLed":
            if "state" in params:
                front_led_on = (params["state"] == "1")
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setServo":
            if "angle" in params and current_port_mode == MODE_SERVO:
                set_servo_angle(int(params["angle"]))
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setOledConfig":
            if "mode" in params:
                oled_mode = int(params["mode"])
                if oled_mode == 3:
                    stop_motors(); dino_jump()
                elif oled_mode == 5:
                    stop_motors(); init_invaders()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setRgb":
            if "mode" in params:
                rgb_mode = params["mode"]
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setRgbCustom":
            if "r" in params and "g" in params and "b" in params:
                rgb_custom = (int(params["r"]), int(params["g"]), int(params["b"]))
                rgb_mode = "custom"
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setRgbBrightness":
            if "b" in params:
                rgb_brightness = max(0, min(255, int(params["b"])))
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/setMode":
            m = params.get("mode", "idle")
            if m == "idle":
                set_modular_port_idle()
            elif port_detect.value() != 0:
                cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nPort empty!")
                cl.close()
                return
            elif m == "distance":
                activate_distance()
            elif m == "dht11":
                activate_dht11()
            elif m == "dht22":
                activate_dht22()
            elif m == "ldr":
                activate_ldr()
            elif m == "rgb":
                activate_rgb()
            elif m == "oled":
                activate_oled()
            elif m == "accel":
                activate_accel()
            elif m == "servo":
                activate_servo()
            else:
                set_modular_port_idle()
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nOK")
        elif path == "/data":
            modes_str = {
                MODE_IDLE: "idle", MODE_DISTANCE: "distance", MODE_DHT11: "dht11",
                MODE_DHT22: "dht22", MODE_LDR: "ldr", MODE_RGB: "rgb",
                MODE_OLED: "oled", MODE_ACCEL: "accel", MODE_SERVO: "servo"
            }
            is_conn = (port_detect.value() == 0)

            json_resp = (
                f'{{"connected":{str(is_conn).lower()},'
                f'"reading":"{latest_reading}",'
                f'"mode":"{modes_str.get(current_port_mode, "idle")}",'
                f'"pwm":{current_speed_pwm},'
                f'"dist_mm":{latest_dist_mm}}}'
            )
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: application/json\r\n\r\n{json_resp}")
        else:
            cl.send(f"HTTP/1.1 200 OK\r\n{cors}Content-Type: text/plain\r\n\r\nSnap Racer API Online")
    except Exception:
        pass
    finally:
        try:
            cl.close()
        except Exception:
            pass

# ================= MAIN EXECUTION LOOP =================
print("SNAP RACER MicroPython firmware active!")
set_modular_port_idle()

while True:
    now = time.ticks_ms()

    # Core background tasks
    service_background_tasks()

    # Drive Watchdog
    if not custom_script_active and current_dir != DIR_STOP and not stop_held:
        if time.ticks_diff(now, last_drive_time) > DRIVE_WATCHDOG_MS:
            stop_motors()

    # LED Indicator Logic
    front_led.value(1 if front_led_on else 0)
    back_led.value(1 if (reverse_active or stop_held) else 0)

    # Launch pending script without blocking main loop
    if script_pending_start:
        script_pending_start = False
        run_custom_executable()

    time.sleep_ms(2)