import subprocess
import sys

PORT = "COM9"

subprocess.run([
    sys.executable,
    "-m", "mpremote",
    "connect", PORT,
    "fs", "cp", "main.py", ":main.py"
], check=True)

subprocess.run([
    sys.executable,
    "-m", "mpremote",
    "connect", PORT,
    "reset"
], check=True)

print("MicroPython upload complete!")