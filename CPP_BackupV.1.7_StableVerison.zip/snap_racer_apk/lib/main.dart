import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:sensors_plus/sensors_plus.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SnapRacerApp(),
  ));
}

class SnapRacerApp extends StatefulWidget {
  const SnapRacerApp({super.key});

  @override
  State<SnapRacerApp> createState() => _SnapRacerAppState();
}

class _SnapRacerAppState extends State<SnapRacerApp> {
  late final WebViewController _controller;
  bool _isConnected = false;
  bool _isRotationLocked = false;
  
  StreamSubscription<AccelerometerEvent>? _accelSubscription;
  DateTime _lastSensorSend = DateTime.now();

  void _reconnect() {
    _controller.loadRequest(Uri.parse('http://192.168.4.1'));
  }

  // --- SCREEN ROTATION LOCK TOGGLE ---
  void _toggleRotationLock() {
    setState(() {
      _isRotationLocked = !_isRotationLocked;
    });

    if (_isRotationLocked) {
      final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;
      if (isLandscape) {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
      } else {
        SystemChrome.setPreferredOrientations([
          DeviceOrientation.portraitUp,
        ]);
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Screen Rotation Locked'),
          duration: Duration(milliseconds: 900),
          backgroundColor: Color(0xFF1E1E1E),
        ),
      );
    } else {
      SystemChrome.setPreferredOrientations(DeviceOrientation.values);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Screen Rotation Unlocked (Auto-Rotate ON)'),
          duration: Duration(milliseconds: 900),
          backgroundColor: Color(0xFF1E1E1E),
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();

    final PlatformWebViewControllerCreationParams params =
        const PlatformWebViewControllerCreationParams();

    final WebViewController controller =
        WebViewController.fromPlatformCreationParams(params);

    controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0D0D0D))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) {
            setState(() {
              _isConnected = true;
            });

            // =======================================================
            // INJECT 60FPS SMOOTHING ENGINE INTO WEBVIEW
            // This feeds smoothed target angles into the ORIGINAL
            // processTilt function, ensuring the motors turn properly.
            // =======================================================
            controller.runJavaScript('''
              window.targetTiltRaw = 0;
              window.currentTiltRaw = 0;
              window.isLerpRunning = false;

              // Flutter calls this function to set the target angle
              window.updateTargetTilt = function(tiltVal) {
                window.targetTiltRaw = tiltVal;
                
                // Start the 60fps render loop if it's not already running
                if (!window.isLerpRunning) {
                  window.isLerpRunning = true;
                  requestAnimationFrame(lerpWheel);
                }
              };

              function lerpWheel() {
                if (!window.gyroModeActive) { 
                  window.isLerpRunning = false; 
                  return; 
                }

                // 60FPS Smooth Interpolation (Lerp)
                window.currentTiltRaw += (window.targetTiltRaw - window.currentTiltRaw) * 0.20;
                
                // Disable CSS lag on the wheel element
                const sw = document.getElementById('steerWheel');
                if (sw) sw.style.transition = 'none';

                // Feed the smoothed value into the ORIGINAL web page logic
                // This guarantees the motors trigger correctly!
                if (typeof window.processTilt === "function") {
                  window.processTilt(window.currentTiltRaw);
                }

                requestAnimationFrame(lerpWheel);
              }
            ''');

            _startNativeTiltStream();
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame == true) {
              setState(() {
                _isConnected = false;
              });
              _stopNativeTiltStream();
              Future.delayed(const Duration(seconds: 2), () {
                if (mounted && !_isConnected) {
                  controller.loadRequest(Uri.parse('http://192.168.4.1'));
                }
              });
            }
          },
        ),
      );

    controller.loadRequest(Uri.parse('http://192.168.4.1'));
    _controller = controller;
  }

  // --- NATIVE HARDWARE ACCELEROMETER SENSOR ---
  void _startNativeTiltStream() {
    _accelSubscription?.cancel();

    _accelSubscription = accelerometerEventStream().listen((AccelerometerEvent event) {
      if (!_isConnected || !mounted) return;

      // Relaxed update rate (~30Hz) so we don't choke the IPC Bridge.
      // The JS Engine injected above handles the 60fps visual smoothness!
      final now = DateTime.now();
      if (now.difference(_lastSensorSend).inMilliseconds < 33) return;
      _lastSensorSend = now;

      final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;

      // Calculate tilt angle in degrees from raw gravity vector
      // NOTE: Signs are flipped to correct the inverted left/right steering!
      double rawAngle;
      if (isLandscape) {
        rawAngle = (event.y / 9.8) * 45.0;  // Flipped sign
      } else {
        rawAngle = -(event.x / 9.8) * 45.0; // Flipped sign
      }

      final targetTilt = rawAngle.clamp(-45.0, 45.0);

      // Just pass the target angle. JS takes care of the smooth animation & motor commands.
      _controller.runJavaScript('if (window.updateTargetTilt) { window.updateTargetTilt(${targetTilt.toStringAsFixed(1)}); }');
    });
  }

  void _stopNativeTiltStream() {
    _accelSubscription?.cancel();
    _accelSubscription = null;
  }

  @override
  void dispose() {
    _stopNativeTiltStream();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: SafeArea(
        child: Stack(
          children: [
            WebViewWidget(controller: _controller),

            // Disconnected / Reconnecting Screen
            if (!_isConnected)
              Container(
                color: const Color(0xFF0D0D0D),
                alignment: Alignment.center,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 45,
                      height: 45,
                      child: CircularProgressIndicator(color: Colors.blueAccent),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Connecting to Snap Racer...',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Turn OFF Mobile Data & Connect to SNAP-RACER Wi-Fi',
                      style: TextStyle(color: Colors.grey[400], fontSize: 12),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1F1F1F),
                        foregroundColor: Colors.blueAccent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: const BorderSide(color: Colors.blueAccent, width: 1),
                        ),
                      ),
                      onPressed: _reconnect,
                      icon: const Icon(Icons.refresh, size: 18),
                      label: const Text('Retry Now'),
                    ),
                  ],
                ),
              ),

            // Top-Right Floating Controls (Rotation Lock & Reconnect)
            Positioned(
              top: 10,
              right: 10,
              child: Row(
                children: [
                  // Rotation Lock Button
                  GestureDetector(
                    onTap: _toggleRotationLock,
                    child: Container(
                      width: 38,
                      height: 38,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xD91E1E1E),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _isRotationLocked ? Colors.blueAccent : Colors.white24,
                          width: 1,
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black54,
                            blurRadius: 4,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Icon(
                        _isRotationLocked
                            ? Icons.screen_lock_rotation
                            : Icons.screen_rotation,
                        color: _isRotationLocked ? Colors.blueAccent : Colors.grey[400],
                        size: 20,
                      ),
                    ),
                  ),

                  // Reconnect / Refresh Button
                  GestureDetector(
                    onTap: _reconnect,
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: const Color(0xD91E1E1E),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white24, width: 1),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black54,
                            blurRadius: 4,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.refresh,
                        color: Colors.blueAccent,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}