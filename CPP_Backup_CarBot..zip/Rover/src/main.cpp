#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Wire.h>
#include "Adafruit_VL53L0X.h"
#include "DHT.h"
#include <Adafruit_Sensor.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>
#include <Update.h>  

// ================= PINS CONFIGURATION =================
#define IN1 0
#define IN2 1
#define IN3 3
#define IN4 4
#define FRONT_LED_PIN 6
#define BACK_LED_PIN  7
#define PORT_SCL_PIN  5
#define PORT_SDA_PIN  10
#define PORT_DETECT_PIN 20
#define MPU_SCL_PIN 8
#define MPU_SDA_PIN 21
#define MPU_ADDR    0x68

// ================= INBUILT MPU-6050 (FAST BIT-BANG I2C) =================
bool inbuiltImuReady = false, tiltAlertActive = false;
float imuPitch = 0.0, imuRoll = 0.0, imuTilt = 0.0, imuAx = 0.0, imuAy = 0.0, imuAz = 9.8;
unsigned long lastImuReadTime = 0;

inline void mpuDly()     { delayMicroseconds(1); }
inline void mpuSclHi()   { pinMode(MPU_SCL_PIN, INPUT_PULLUP); }
inline void mpuSclLo()   { pinMode(MPU_SCL_PIN, OUTPUT); digitalWrite(MPU_SCL_PIN, LOW); }
inline void mpuSdaHi()   { pinMode(MPU_SDA_PIN, INPUT_PULLUP); }
inline void mpuSdaLo()   { pinMode(MPU_SDA_PIN, OUTPUT); digitalWrite(MPU_SDA_PIN, LOW); }

void mpuStart() { mpuSdaHi(); mpuSclHi(); mpuDly(); mpuSdaLo(); mpuDly(); mpuSclLo(); mpuDly(); }
void mpuStop()  { mpuSdaLo(); mpuDly(); mpuSclHi(); mpuDly(); mpuSdaHi(); mpuDly(); }

bool mpuWrite(uint8_t d) {
  for (uint8_t i = 0; i < 8; i++) {
    if (d & 0x80) mpuSdaHi(); else mpuSdaLo();
    mpuDly(); mpuSclHi(); mpuDly(); mpuSclLo(); mpuDly(); d <<= 1;
  }
  mpuSdaHi(); mpuDly(); mpuSclHi(); mpuDly();
  bool ack = (digitalRead(MPU_SDA_PIN) == LOW);
  mpuSclLo(); mpuDly(); return ack;
}

uint8_t mpuRead(bool ack) {
  mpuSdaHi(); uint8_t d = 0;
  for (uint8_t i = 0; i < 8; i++) {
    d <<= 1; mpuSclHi(); mpuDly();
    if (digitalRead(MPU_SDA_PIN)) d |= 1;
    mpuSclLo(); mpuDly();
  }
  if (ack) mpuSdaLo(); else mpuSdaHi();
  mpuDly(); mpuSclHi(); mpuDly(); mpuSclLo(); mpuSdaHi(); mpuDly();
  return d;
}

bool initMpu6050() {
  mpuSdaHi(); mpuSclHi(); delay(30);
  mpuStart();
  if (!mpuWrite(MPU_ADDR << 1)) { mpuStop(); return false; }
  mpuWrite(0x6B); mpuWrite(0x00); mpuStop(); delay(10);
  return true;
}

bool readMpuAccel(float &ax, float &ay, float &az) {
  mpuStart();
  if (!mpuWrite(MPU_ADDR << 1)) { mpuStop(); return false; }
  mpuWrite(0x3B); mpuStart();
  if (!mpuWrite((MPU_ADDR << 1) | 1)) { mpuStop(); return false; }
  uint8_t raw[6];
  for (int i = 0; i < 5; i++) raw[i] = mpuRead(true);
  raw[5] = mpuRead(false); mpuStop();
  ax = (float)((int16_t)((raw[0] << 8) | raw[1])) * 0.00059855f;
  ay = (float)((int16_t)((raw[2] << 8) | raw[3])) * 0.00059855f;
  az = (float)((int16_t)((raw[4] << 8) | raw[5])) * 0.00059855f;
  return true;
}

// ================= PERIPHERALS & NETWORKING =================
WebServer server(80);
DNSServer dnsServer;
Adafruit_NeoPixel strip(8, PORT_SCL_PIN, NEO_GRB + NEO_KHZ800);
Adafruit_SSD1306 display(128, 64, &Wire, -1);
Adafruit_VL53L0X vl53 = Adafruit_VL53L0X();
DHT dht11(PORT_SCL_PIN, DHT11);
DHT dht22(PORT_SCL_PIN, DHT22);
Servo modServo;

const unsigned long DRIVE_WATCHDOG_MS = 1200;
const unsigned long STOP_WAIT_TIME    = 200;
const unsigned long REVERSE_TIME      = 600;

bool oledReady = false, wasConnected = false, autoBrakeEnabled = false, ldrIsDark = false, tempAlertActive = false;
bool servoAttached = false;
int currentServoAngle = 90;

unsigned long lastOledUpdate = 0, lastDriveTime = 0, obstacleStartTime = 0, lastPortReadTime = 0, lastRgbUpdate = 0;
int oledAnim = 0, currentSpeedPwm = 0, rgbStep = 0, breathBrightness = 0, breathDir = 1, rgbBrightness = 80;
uint8_t rgbCustomR = 0, rgbCustomG = 122, rgbCustomB = 255;
bool policeToggle = false, frontLedOn = false, reverseActive = false, stopHeld = false;

// Modular Accelerometer State
uint8_t modAccelType = 0, modAccelAddr = 0x53;
bool modTiltAlertActive = false;
float modTiltThreshold = 35.0;
int modAccelAction = 1;
float modPitch = 0.0, modRoll = 0.0, modTilt = 0.0, modAx = 0.0, modAy = 0.0, modAz = 9.8;

// ENUMS
enum PortMode { MODE_IDLE, MODE_DISTANCE, MODE_DHT11, MODE_DHT22, MODE_LDR, MODE_RGB, MODE_OLED, MODE_ACCEL, MODE_SERVO };
PortMode currentPortMode = MODE_IDLE;

enum DriveDir { DIR_STOP, DIR_FWD, DIR_BACK, DIR_LEFT, DIR_RIGHT };
DriveDir currentDir = DIR_STOP;

enum ObstacleState { NORMAL, WAITING, EXECUTING };
ObstacleState obstacleState = NORMAL;

enum RgbMode { RGB_OFF, RGB_RAINBOW, RGB_BREATHING, RGB_RED, RGB_GREEN, RGB_BLUE, RGB_POLICE, RGB_CHASE, RGB_AUTO, RGB_CUSTOM, RGB_TACHO };
RgbMode currentRgbMode = RGB_OFF;

// Rules configuration
const int AUTO_MANEUVER_PWM = 185;
int obstacleDistance = 60, obstacleAction = 0, ldrDarkAction = 1, dhtAction = 1, adxlAction = 1;
int oledMode = 0; 
float tempThreshold = 38.0, tiltThreshold = 35.0;
String oledLine1 = "SNAP RACER", oledLine2 = "SYSTEM ACTIVE", latestReading = "Safe Mode (Idle)";
int latestDistMm = -1;

// ================= DINO GAME ENGINE =================
const int DINO_GROUND = 42;
float dinoY = DINO_GROUND, dinoVelocityY = 0.0;
bool dinoDucking = false, dinoGameOver = false;
int dinoScore = 0, dinoObstacleX = 130, dinoObstacleType = 0, dinoGroundScroll = 0;

inline bool isDinoMode() { return (currentPortMode == MODE_OLED && oledMode == 3); }

void dinoJump() {
  if (dinoGameOver) {
    dinoGameOver = false; dinoScore = 0; dinoObstacleX = 130; dinoY = DINO_GROUND; dinoVelocityY = 0; dinoDucking = false; return;
  }
  if (dinoY >= DINO_GROUND) dinoVelocityY = -6.8f;
}

void dinoCrouch(bool duck) { dinoDucking = duck; }

void drawDinoGame() {
  if (!dinoGameOver) {
    dinoY += dinoVelocityY; dinoVelocityY += 0.9f;
    if (dinoY >= DINO_GROUND) { dinoY = DINO_GROUND; dinoVelocityY = 0; }
    dinoObstacleX -= 4; dinoGroundScroll = (dinoGroundScroll + 3) % 128;

    if (dinoObstacleX < -16) {
      dinoObstacleX = 128 + random(10, 45); dinoObstacleType = random(0, 2); dinoScore++;
    }

    int dinoW = dinoDucking ? 14 : 10;
    int dinoH = dinoDucking ? 8 : 14;
    int dinoBoxY = dinoDucking ? 48 : (int)dinoY;

    if (dinoObstacleType == 0) {
      if (dinoObstacleX < (16 + dinoW) && (dinoObstacleX + 8) > 16 && (dinoBoxY + dinoH) > 45) dinoGameOver = true;
    } else {
      if (dinoObstacleX < (16 + dinoW) && (dinoObstacleX + 10) > 16 && (!dinoDucking || dinoY < DINO_GROUND)) dinoGameOver = true;
    }
  }

  display.drawLine(0, 56, 127, 56, SSD1306_WHITE);
  if (dinoDucking && dinoY >= DINO_GROUND) {
    display.fillRect(14, 49, 10, 6, SSD1306_WHITE); display.fillRect(24, 49, 4, 4, SSD1306_WHITE);
  } else {
    int dy = (int)dinoY;
    display.fillRect(18, dy, 6, 5, SSD1306_WHITE); display.fillRect(16, dy + 4, 6, 7, SSD1306_WHITE);
  }

  display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0); display.print("DINO");
  display.setCursor(75, 0); display.print("SCORE "); display.print(dinoScore);

  if (dinoGameOver) {
    display.fillRect(18, 16, 92, 24, SSD1306_BLACK); display.drawRect(18, 16, 92, 24, SSD1306_WHITE);
    display.setCursor(34, 20); display.print("GAME OVER");
  }
}

// ================= SPACE INVADERS ENGINE =================
int invaderShipX = 58, invaderMoveDir = 0;
bool invaderLaserActive = false;
int invaderLaserX = 0, invaderLaserY = 0;
bool alienAlive[10];
int alienFleetX = 14, alienFleetY = 12, alienFleetDir = 1, invaderScore = 0;
bool invaderGameOver = false;
unsigned long lastAlienStep = 0;

inline bool isInvadersMode() { return (currentPortMode == MODE_OLED && oledMode == 5); }

void initSpaceInvaders() {
  invaderShipX = 58; invaderMoveDir = 0; invaderLaserActive = false;
  alienFleetX = 14; alienFleetY = 12; alienFleetDir = 1; invaderScore = 0; invaderGameOver = false;
  for (int i = 0; i < 10; i++) alienAlive[i] = true;
}

void invaderFire() {
  if (invaderGameOver) { initSpaceInvaders(); return; }
  if (!invaderLaserActive) { invaderLaserActive = true; invaderLaserX = invaderShipX + 5; invaderLaserY = 50; }
}

void drawSpaceInvaders() {
  invaderShipX = constrain(invaderShipX + invaderMoveDir * 3, 2, 114);
  if (invaderLaserActive && (invaderLaserY -= 5) < 4) invaderLaserActive = false;

  if (!invaderGameOver && millis() - lastAlienStep > 110) {
    lastAlienStep = millis(); alienFleetX += alienFleetDir * 3;
    if (alienFleetX > 45 || alienFleetX < 6) { alienFleetDir = -alienFleetDir; alienFleetY += 3; }
  }

  for (int row = 0; row < 2; row++) {
    for (int col = 0; col < 5; col++) {
      int idx = row * 5 + col;
      if (alienAlive[idx]) {
        int ax = alienFleetX + col * 14, ay = alienFleetY + row * 9;
        if (invaderLaserActive && invaderLaserX >= ax && invaderLaserX <= ax + 8 && invaderLaserY >= ay && invaderLaserY <= ay + 6) {
          alienAlive[idx] = false; invaderLaserActive = false; invaderScore += 10;
        }
        if (ay + 6 >= 52) invaderGameOver = true;
      }
    }
  }

  display.setTextSize(1); display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0); display.print("INVADERS");
  display.setCursor(75, 0); display.print("SCORE "); display.print(invaderScore);
  if (invaderLaserActive) display.drawFastVLine(invaderLaserX, invaderLaserY, 4, SSD1306_WHITE);
  display.fillRect(invaderShipX, 58, 12, 4, SSD1306_WHITE);
}

inline bool isManeuverActive() { return (obstacleState != NORMAL) && (obstacleAction == 0 ? autoBrakeEnabled : true); }

// ================= CORS-ENABLED RESPONSE =================
void sendOk() { 
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "*");
  server.send(200, "text/plain", "OK"); 
}

void setMotors(int a, int b, int c, int d, DriveDir dir, bool rev) {
  bool ldrEmergencyStop = (currentPortMode == MODE_LDR && ldrDarkAction == 3 && ldrIsDark);
  bool modAccelStop = (currentPortMode == MODE_ACCEL && modAccelAction == 1 && modTiltAlertActive);
  if (currentSpeedPwm == 0 || (adxlAction == 1 && tiltAlertActive) || (dhtAction == 2 && tempAlertActive) || ldrEmergencyStop || modAccelStop) {
    analogWrite(IN1, 0); analogWrite(IN2, 0); analogWrite(IN3, 0); analogWrite(IN4, 0);
    currentDir = DIR_STOP; reverseActive = false; return;
  }
  analogWrite(IN1, a ? currentSpeedPwm : 0); analogWrite(IN2, b ? currentSpeedPwm : 0);
  analogWrite(IN3, c ? currentSpeedPwm : 0); analogWrite(IN4, d ? currentSpeedPwm : 0);
  currentDir = dir; reverseActive = rev;
}

void stopMotors()   { setMotors(0, 0, 0, 0, DIR_STOP, false); }
void moveForward()  { if (isDinoMode()) { dinoJump(); return; } if (isInvadersMode()) { invaderFire(); return; } if (!isManeuverActive()) setMotors(1, 0, 1, 0, DIR_FWD, false); }
void moveBackward() { if (isDinoMode()) { dinoCrouch(true); return; } if (!isManeuverActive()) setMotors(0, 1, 0, 1, DIR_BACK, true); }
void turnLeft()     { if (isInvadersMode()) { invaderMoveDir = -1; return; } if (!isManeuverActive()) setMotors(0, 1, 1, 0, DIR_LEFT, false); }
void turnRight()    { if (isInvadersMode()) { invaderMoveDir = 1; return; } if (!isManeuverActive()) setMotors(1, 0, 0, 1, DIR_RIGHT, false); }

void setAllPixels(uint8_t r, uint8_t g, uint8_t b) { for (int i = 0; i < 8; i++) strip.setPixelColor(i, strip.Color(r, g, b)); strip.show(); }
void clearStrip() { strip.clear(); strip.show(); }

void updateRgb() {
  if (currentPortMode != MODE_RGB) return;
  unsigned long now = millis();
  
  if (currentRgbMode == RGB_TACHO) {
    int litLeds = map(currentSpeedPwm, 0, 255, 0, 8);
    if (currentSpeedPwm > 8 && litLeds == 0) litLeds = 1;
    if (currentSpeedPwm >= 248) {
      bool flash = (now / 70) % 2;
      if (flash) setAllPixels(255, 0, 0); else clearStrip();
      return;
    }
    strip.clear();
    for (int i = 0; i < 8; i++) {
      if (i < litLeds) {
        if (i < 3) strip.setPixelColor(i, strip.Color(0, 255, 0));
        else if (i < 6) strip.setPixelColor(i, strip.Color(255, 140, 0));
        else strip.setPixelColor(i, strip.Color(255, 0, 0));
      }
    }
    strip.show();
    return;
  }

  if (currentRgbMode == RGB_CUSTOM) { setAllPixels(rgbCustomR, rgbCustomG, rgbCustomB); return; }
  if (currentRgbMode == RGB_AUTO) {
    switch (currentDir) {
      case DIR_FWD:  setAllPixels(180, 180, 180); break;
      case DIR_BACK: setAllPixels(255, 0, 0); break;
      case DIR_STOP: setAllPixels(stopHeld ? 255 : 20, stopHeld ? 0 : 20, stopHeld ? 0 : 20); break;
      default: break;
    }
    return;
  }

  switch (currentRgbMode) {
    case RGB_OFF: clearStrip(); break;
    case RGB_RED: setAllPixels(255, 0, 0); break;
    case RGB_GREEN: setAllPixels(0, 255, 0); break;
    case RGB_BLUE: setAllPixels(0, 0, 255); break;
    case RGB_RAINBOW:
      if (now - lastRgbUpdate > 25) { lastRgbUpdate = now; for (int i = 0; i < 8; i++) strip.setPixelColor(i, strip.ColorHSV(((i * 65536 / 8) + rgbStep) % 65536)); strip.show(); rgbStep += 256; } break;
    case RGB_BREATHING:
      if (now - lastRgbUpdate > 15) { lastRgbUpdate = now; breathBrightness += breathDir * 4; if (breathBrightness >= 180) { breathBrightness = 180; breathDir = -1; } else if (breathBrightness <= 5) { breathBrightness = 5; breathDir = 1; } setAllPixels(breathBrightness, breathBrightness, breathBrightness); } break;
    case RGB_POLICE:
      if (now - lastRgbUpdate > 120) { lastRgbUpdate = now; policeToggle = !policeToggle; for (int i = 0; i < 4; i++) strip.setPixelColor(i, policeToggle ? strip.Color(255, 0, 0) : strip.Color(0, 0, 255)); for (int i = 4; i < 8; i++) strip.setPixelColor(i, policeToggle ? strip.Color(0, 0, 255) : strip.Color(255, 0, 0)); strip.show(); } break;
    case RGB_CHASE:
      if (now - lastRgbUpdate > 60) { lastRgbUpdate = now; strip.clear(); int p = rgbStep % 8; strip.setPixelColor(p, strip.Color(0, 180, 255)); strip.setPixelColor((p + 1) % 8, strip.Color(0, 80, 120)); strip.show(); rgbStep++; } break;
    default: break;
  }
}

void updateOledScreen() {
  int frameInterval = (oledMode == 3 || oledMode == 5) ? 35 : 90;
  if (!oledReady || currentPortMode != MODE_OLED || millis() - lastOledUpdate < frameInterval) return;
  lastOledUpdate = millis(); oledAnim++;
  display.clearDisplay(); display.setTextColor(SSD1306_WHITE);
  if (oledMode == 5) drawSpaceInvaders();
  else if (oledMode == 3) drawDinoGame();
  else if (oledMode == 1) {
    display.setTextSize(1); display.setCursor(0, 0); display.print("SNAP RACER TELEMETRY");
    display.setCursor(0, 15); display.print("Speed: " + String(currentSpeedPwm) + " PWM");
    display.setCursor(0, 27); display.print("Tilt : " + String(imuTilt, 0) + " deg");
  } else if (oledMode == 2) {
    display.setTextSize(1); display.setCursor(8, 24); display.print(oledLine1);
    display.setCursor(8, 40); display.print(oledLine2);
  } else {
    display.setTextSize(1); display.setCursor(20, 25); display.print("SYSTEM ACTIVE");
  }
  display.display();
}

void setModularPortIdle() { 
  if (oledReady) { display.clearDisplay(); display.display(); oledReady = false; } 
  clearStrip(); currentRgbMode = RGB_OFF;
  if (servoAttached) { modServo.detach(); servoAttached = false; }
  Wire.end(); pinMode(PORT_SCL_PIN, INPUT); pinMode(PORT_SDA_PIN, INPUT); 
  currentPortMode = MODE_IDLE; obstacleState = NORMAL; stopMotors(); tempAlertActive = false;
  modAccelType = 0; modTiltAlertActive = false; latestDistMm = -1;
  latestReading = "Safe Mode (Idle)";
}

void activateDistance() { 
  setModularPortIdle(); Wire.begin(PORT_SDA_PIN, PORT_SCL_PIN); Wire.setTimeOut(20); delay(25); 
  if (vl53.begin()) { vl53.startRangeContinuous(25); currentPortMode = MODE_DISTANCE; latestReading = "Measuring..."; } 
  else { setModularPortIdle(); latestReading = "Error: VL53L0X not found"; }
}
void activateDHT11() { setModularPortIdle(); dht11.begin(); currentPortMode = MODE_DHT11; lastPortReadTime = millis() - 1500; latestReading = "Reading DHT11..."; }
void activateDHT22() { setModularPortIdle(); dht22.begin(); currentPortMode = MODE_DHT22; lastPortReadTime = millis() - 1500; latestReading = "Reading DHT22..."; }
void activateLDR()   { setModularPortIdle(); pinMode(PORT_SCL_PIN, INPUT_PULLUP); currentPortMode = MODE_LDR; latestReading = "Reading LDR..."; }
void activateRGB()   { setModularPortIdle(); currentPortMode = MODE_RGB; latestReading = "RGB Ring Active"; strip.begin(); strip.setBrightness(rgbBrightness); clearStrip(); }
void activateOLED()  {
  setModularPortIdle(); Wire.begin(PORT_SDA_PIN, PORT_SCL_PIN); Wire.setClock(400000); delay(25);
  if (display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { oledReady = true; currentPortMode = MODE_OLED; latestReading = "OLED Online"; display.clearDisplay(); display.display(); } 
  else { setModularPortIdle(); latestReading = "Error: OLED not found"; }
}

void activateAccel() {
  setModularPortIdle(); Wire.begin(PORT_SDA_PIN, PORT_SCL_PIN); Wire.setClock(100000); delay(25);
  Wire.beginTransmission(0x53);
  if (Wire.endTransmission() == 0) {
    Wire.beginTransmission(0x53); Wire.write(0x2D); Wire.write(0x08); Wire.endTransmission();
    modAccelType = 1; modAccelAddr = 0x53; currentPortMode = MODE_ACCEL; latestReading = "ADXL345 Online"; return;
  }
  setModularPortIdle(); latestReading = "Error: Accel not found";
}

void activateServo() {
  setModularPortIdle();
  ESP32PWM::allocateTimer(0); ESP32PWM::allocateTimer(1); ESP32PWM::allocateTimer(2); ESP32PWM::allocateTimer(3);
  modServo.setPeriodHertz(50);
  modServo.attach(PORT_SCL_PIN, 500, 2400);
  currentServoAngle = 90;
  modServo.write(currentServoAngle);
  servoAttached = true;
  currentPortMode = MODE_SERVO;
  latestReading = "Servo: 90 deg";
}

// ================= API ENDPOINTS =================
void handleSetSpeed() { 
  if (server.hasArg("pwm")) { 
    currentSpeedPwm = constrain(server.arg("pwm").toInt(), 0, 255); 
    if (currentSpeedPwm == 0) stopMotors(); 
    else if (currentDir != DIR_STOP) {
      setMotors(currentDir == DIR_FWD || currentDir == DIR_RIGHT, 
                currentDir == DIR_BACK || currentDir == DIR_LEFT, 
                currentDir == DIR_FWD || currentDir == DIR_LEFT, 
                currentDir == DIR_BACK || currentDir == DIR_RIGHT, 
                currentDir, currentDir == DIR_BACK); 
    }
  } 
  sendOk(); 
}

void handleSetObstacle() { if (server.hasArg("enabled")) { autoBrakeEnabled = (server.arg("enabled") == "1"); } sendOk(); }
void handleSetFrontLed() { if (server.hasArg("state")) frontLedOn = (server.arg("state") == "1"); sendOk(); }
void handleSetDistConfig() { if (server.hasArg("dist")) obstacleDistance = constrain(server.arg("dist").toInt(), 10, 600); if (server.hasArg("action")) obstacleAction = server.arg("action").toInt(); sendOk(); }
void handleSetLdrConfig() { if (server.hasArg("action")) ldrDarkAction = server.arg("action").toInt(); sendOk(); }
void handleSetDhtConfig() { if (server.hasArg("temp")) tempThreshold = server.arg("temp").toFloat(); if (server.hasArg("action")) dhtAction = server.arg("action").toInt(); sendOk(); }
void handleSetAdxlConfig() { if (server.hasArg("angle")) tiltThreshold = server.arg("angle").toFloat(); if (server.hasArg("action")) adxlAction = server.arg("action").toInt(); sendOk(); }
void handleSetModAccelConfig() { if (server.hasArg("angle")) modTiltThreshold = server.arg("angle").toFloat(); if (server.hasArg("action")) modAccelAction = server.arg("action").toInt(); sendOk(); }

void handleSetServo() {
  if (server.hasArg("angle") && currentPortMode == MODE_SERVO && servoAttached) {
    currentServoAngle = constrain(server.arg("angle").toInt(), 0, 180);
    modServo.write(currentServoAngle);
    latestReading = "Servo: " + String(currentServoAngle) + " deg";
  }
  sendOk();
}

void handleSetOledConfig() { 
  if (server.hasArg("mode")) {
    oledMode = server.arg("mode").toInt(); 
    if (oledMode == 3) { stopMotors(); dinoGameOver = false; dinoScore = 0; dinoObstacleX = 130; dinoY = DINO_GROUND; }
    else if (oledMode == 5) { stopMotors(); initSpaceInvaders(); }
  } 
  if (server.hasArg("l1")) oledLine1 = server.arg("l1"); 
  if (server.hasArg("l2")) oledLine2 = server.arg("l2"); 
  sendOk(); 
}

void handleResetModRules() {
  obstacleDistance = 60; obstacleAction = 0; autoBrakeEnabled = false; obstacleState = NORMAL;
  ldrDarkAction = 1; ldrIsDark = false; tempThreshold = 38.0; dhtAction = 1; tempAlertActive = false;
  modTiltThreshold = 35.0; modAccelAction = 1; modTiltAlertActive = false;
  oledMode = 0; oledLine1 = "SNAP RACER"; oledLine2 = "SYSTEM ACTIVE";
  currentRgbMode = RGB_OFF; rgbBrightness = 80; latestDistMm = -1;
  if (currentPortMode == MODE_RGB) clearStrip();
  if (currentPortMode == MODE_SERVO && servoAttached) { currentServoAngle = 90; modServo.write(90); latestReading = "Servo: 90 deg"; }
  sendOk();
}

void handleSetRgb() {
  if (server.hasArg("mode")) {
    String m = server.arg("mode");
    if (m == "off") currentRgbMode = RGB_OFF; else if (m == "rainbow") currentRgbMode = RGB_RAINBOW;
    else if (m == "breathing") currentRgbMode = RGB_BREATHING; else if (m == "red") currentRgbMode = RGB_RED;
    else if (m == "green") currentRgbMode = RGB_GREEN; else if (m == "blue") currentRgbMode = RGB_BLUE;
    else if (m == "police") currentRgbMode = RGB_POLICE; else if (m == "chase") currentRgbMode = RGB_CHASE;
    else if (m == "auto") currentRgbMode = RGB_AUTO; else if (m == "tacho") currentRgbMode = RGB_TACHO;
    rgbStep = 0; breathBrightness = 0; breathDir = 1; policeToggle = false; lastRgbUpdate = 0;
    if (currentRgbMode == RGB_OFF && currentPortMode == MODE_RGB) clearStrip();
  }
  sendOk();
}

void handleSetRgbCustom() {
  if (server.hasArg("r") && server.hasArg("g") && server.hasArg("b")) {
    rgbCustomR = server.arg("r").toInt(); rgbCustomG = server.arg("g").toInt(); rgbCustomB = server.arg("b").toInt();
    currentRgbMode = RGB_CUSTOM;
    if (currentPortMode == MODE_RGB) setAllPixels(rgbCustomR, rgbCustomG, rgbCustomB);
  }
  sendOk();
}

void handleSetRgbBrightness() {
  if (server.hasArg("b")) {
    rgbBrightness = constrain(server.arg("b").toInt(), 0, 255);
    if (currentPortMode == MODE_RGB) { strip.setBrightness(rgbBrightness); strip.show(); }
  }
  sendOk();
}

void handleSetMode() { 
  if (server.hasArg("mode")) { 
    String m = server.arg("mode");
    if (m == "idle") { setModularPortIdle(); sendOk(); return; }
    if (digitalRead(PORT_DETECT_PIN) != LOW) { 
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.send(200, "text/plain", "Port empty!"); return; 
    } 
    if (m == "distance") activateDistance(); else if (m == "dht11") activateDHT11(); 
    else if (m == "dht22") activateDHT22(); else if (m == "ldr") activateLDR(); 
    else if (m == "rgb") activateRGB(); else if (m == "oled") activateOLED(); 
    else if (m == "accel") activateAccel(); else if (m == "servo") activateServo();
    else setModularPortIdle(); 
  } 
  sendOk(); 
}

void handleData() { 
  bool isConnected = (digitalRead(PORT_DETECT_PIN) == LOW); 
  const char* mStr = "idle"; 
  switch (currentPortMode) { 
    case MODE_DISTANCE: mStr = "distance"; break; case MODE_DHT11: mStr = "dht11"; break; 
    case MODE_DHT22:    mStr = "dht22"; break; case MODE_LDR:      mStr = "ldr"; break; 
    case MODE_RGB:      mStr = "rgb"; break; case MODE_OLED:     mStr = "oled"; break; 
    case MODE_ACCEL:    mStr = "accel"; break; case MODE_SERVO:    mStr = "servo"; break;
    default: break; 
  } 

  float outPitch = (currentPortMode == MODE_ACCEL) ? modPitch : imuPitch;
  float outRoll  = (currentPortMode == MODE_ACCEL) ? modRoll  : imuRoll;
  float outTilt  = (currentPortMode == MODE_ACCEL) ? modTilt  : imuTilt;
  float outAx    = (currentPortMode == MODE_ACCEL) ? modAx    : imuAx;
  float outAy    = (currentPortMode == MODE_ACCEL) ? modAy    : imuAy;
  float outAz    = (currentPortMode == MODE_ACCEL) ? modAz    : imuAz;
  bool outAlert  = (currentPortMode == MODE_ACCEL) ? modTiltAlertActive : tiltAlertActive;
  bool outImuOk  = (currentPortMode == MODE_ACCEL) ? true : inbuiltImuReady;

  String readingOut = (currentPortMode == MODE_IDLE) ? "Safe Mode (Idle)" : latestReading;
  String json = "{\"connected\":" + String(isConnected ? "true" : "false") + 
                ",\"reading\":\"" + readingOut + 
                "\",\"mode\":\"" + String(mStr) + 
                "\",\"imu_ok\":" + String(outImuOk ? "true" : "false") + 
                ",\"pitch\":" + String(outPitch, 1) + 
                ",\"roll\":" + String(outRoll, 1) + 
                ",\"tilt\":" + String(outTilt, 1) + 
                ",\"ax\":" + String(outAx, 1) + 
                ",\"ay\":" + String(outAy, 1) + 
                ",\"az\":" + String(outAz, 1) + 
                ",\"tilt_alert\":" + String(outAlert ? "true" : "false") + 
                ",\"pwm\":" + String(currentSpeedPwm) + 
                ",\"dist_mm\":" + String(latestDistMm) + "}";
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json); 
}

void setup() {
  Serial.begin(115200); 
  delay(300);
  
  WiFi.mode(WIFI_AP); 
  WiFi.setSleep(false);
  WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
  WiFi.softAP("SNAP-RACER", "12345678"); 
  
  dnsServer.start(53, "*", IPAddress(192, 168, 4, 1));
  
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT); stopMotors();
  pinMode(FRONT_LED_PIN, OUTPUT); digitalWrite(FRONT_LED_PIN, LOW); 
  pinMode(BACK_LED_PIN, OUTPUT); digitalWrite(BACK_LED_PIN, LOW);
  pinMode(PORT_DETECT_PIN, INPUT_PULLUP);

  if (initMpu6050()) inbuiltImuReady = true;

  server.on("/", [](){ 
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(200, "text/plain", "Snap Racer API Online. Launch index.html to control."); 
  });
  server.on("/forward", [](){ lastDriveTime = millis(); moveForward(); sendOk(); });
  server.on("/backward", [](){ lastDriveTime = millis(); moveBackward(); sendOk(); });
  server.on("/left", [](){ lastDriveTime = millis(); turnLeft(); sendOk(); });
  server.on("/right", [](){ lastDriveTime = millis(); turnRight(); sendOk(); });
  server.on("/stop", [](){ lastDriveTime = 0; if (isDinoMode()) dinoCrouch(false); if (isInvadersMode()) invaderMoveDir = 0; stopMotors(); sendOk(); });
  server.on("/stopStart", [](){ stopHeld = true; stopMotors(); sendOk(); });
  server.on("/stopEnd", [](){ stopHeld = false; sendOk(); });
  server.on("/ping", [](){ if (currentDir != DIR_STOP) lastDriveTime = millis(); sendOk(); });
  server.on("/setSpeed", handleSetSpeed);
  server.on("/setObstacle", handleSetObstacle);
  server.on("/setFrontLed", handleSetFrontLed);
  server.on("/setDistConfig", handleSetDistConfig);
  server.on("/setLdrConfig", handleSetLdrConfig);
  server.on("/setDhtConfig", handleSetDhtConfig);
  server.on("/setAdxlConfig", handleSetAdxlConfig);
  server.on("/setModAccelConfig", handleSetModAccelConfig);
  server.on("/setOledConfig", handleSetOledConfig);
  server.on("/setServo", handleSetServo);
  server.on("/resetModRules", handleResetModRules);
  server.on("/setRgb", handleSetRgb);
  server.on("/setRgbCustom", handleSetRgbCustom);
  server.on("/setRgbBrightness", handleSetRgbBrightness);
  server.on("/setMode", handleSetMode);
  server.on("/data", handleData);
  server.onNotFound([](){ sendOk(); });
  server.begin(); 
  setModularPortIdle();
}

void loop() {
  dnsServer.processNextRequest();
  server.handleClient(); 
  updateRgb(); 
  updateOledScreen();
  
  if (currentDir != DIR_STOP && obstacleState == NORMAL && !stopHeld) { 
    if (millis() - lastDriveTime > DRIVE_WATCHDOG_MS) stopMotors(); 
  }

  // Non-blocking bit-banged MPU-6050 polling (30 Hz / 33ms)
  if (inbuiltImuReady && (millis() - lastImuReadTime >= 33)) {
    lastImuReadTime = millis();
    if (readMpuAccel(imuAx, imuAy, imuAz)) {
      imuPitch = atan2(imuAy, sqrt(imuAx * imuAx + imuAz * imuAz)) * 57.295779f;
      imuRoll  = atan2(-imuAx, imuAz) * 57.295779f;
      imuTilt  = atan2(sqrt(imuAx * imuAx + imuAy * imuAy), fabsf(imuAz)) * 57.295779f;
      tiltAlertActive = (imuTilt >= tiltThreshold);
      if (tiltAlertActive && adxlAction == 1 && currentDir != DIR_STOP) stopMotors();
    }
  }

  // Lighting logic
  bool hazardStrobe = ((dhtAction == 1 && tempAlertActive) || (adxlAction == 2 && tiltAlertActive) || (currentPortMode == MODE_LDR && ldrDarkAction == 2 && ldrIsDark) || (currentPortMode == MODE_ACCEL && modAccelAction == 2 && modTiltAlertActive) || (obstacleState != NORMAL && obstacleAction == 4));
  if (hazardStrobe) {
    bool blink = (millis() / 140) % 2;
    digitalWrite(FRONT_LED_PIN, blink ? HIGH : LOW); digitalWrite(BACK_LED_PIN, blink ? HIGH : LOW);
  } else {
    digitalWrite(FRONT_LED_PIN, frontLedOn ? HIGH : LOW);
    digitalWrite(BACK_LED_PIN, (reverseActive || stopHeld || (obstacleState == EXECUTING && obstacleAction == 0)) ? HIGH : LOW);
  }

  bool isConnected = (digitalRead(PORT_DETECT_PIN) == LOW);
  if (!isConnected && wasConnected) { wasConnected = false; setModularPortIdle(); }
  if (isConnected && !wasConnected) { wasConnected = true; latestReading = "Module connected. Select mode."; }

  if (isConnected) {
    switch (currentPortMode) {
      case MODE_DISTANCE: {
        if (vl53.isRangeComplete()) {
          uint16_t range = vl53.readRangeResult();
          bool ok = (range != 0xFFFF && range > 0 && range < 8190);
          int d = ok ? (int)range : -1;
          latestDistMm = d;
          latestReading = ok ? (String(d) + " mm (" + String(d / 10.0, 1) + " cm)") : "Out of range";
          
          bool distTriggerActive = (obstacleAction == 0) ? autoBrakeEnabled : true;
          if (distTriggerActive) {
            switch (obstacleState) {
              case NORMAL:
                if (ok && d >= 1 && d <= obstacleDistance) {
                  stopMotors(); obstacleState = WAITING; obstacleStartTime = millis();
                }
                break;
              case WAITING:
                stopMotors();
                if (millis() - obstacleStartTime >= STOP_WAIT_TIME) {
                  int actPwm = AUTO_MANEUVER_PWM;
                  obstacleState = EXECUTING; obstacleStartTime = millis();
                  if (obstacleAction == 0) { analogWrite(IN1, 0); analogWrite(IN2, actPwm); analogWrite(IN3, 0); analogWrite(IN4, actPwm); currentDir = DIR_BACK; reverseActive = true; }
                  else if (obstacleAction == 1) stopMotors();
                  else if (obstacleAction == 2) { analogWrite(IN1, 0); analogWrite(IN2, actPwm); analogWrite(IN3, actPwm); analogWrite(IN4, 0); currentDir = DIR_LEFT; }
                  else if (obstacleAction == 3) { analogWrite(IN1, actPwm); analogWrite(IN2, 0); analogWrite(IN3, 0); analogWrite(IN4, actPwm); currentDir = DIR_RIGHT; }
                  else if (obstacleAction == 4) stopMotors();
                }
                break;
              case EXECUTING:
                if (millis() - obstacleStartTime >= REVERSE_TIME) { stopMotors(); obstacleState = NORMAL; }
                break;
            }
          }
        }
        break;
      }
      case MODE_DHT11:
      case MODE_DHT22: {
        if (millis() - lastPortReadTime >= 1000) {
          lastPortReadTime = millis();
          float h = (currentPortMode == MODE_DHT11) ? dht11.readHumidity() : dht22.readHumidity();
          float t = (currentPortMode == MODE_DHT11) ? dht11.readTemperature() : dht22.readTemperature();
          if (!isnan(h) && !isnan(t)) {
            latestReading = String(t, 1) + " C | " + String(h, 0) + " %";
            tempAlertActive = (t >= tempThreshold);
            if (tempAlertActive && dhtAction == 2) stopMotors();
          }
        }
        break;
      }
      case MODE_LDR: {
        if (millis() - lastPortReadTime >= 50) {
          lastPortReadTime = millis();
          ldrIsDark = (digitalRead(PORT_SCL_PIN) == HIGH);
          latestReading = ldrIsDark ? "DARK DETECTED" : "LIGHT DETECTED";
          if (ldrDarkAction == 1) frontLedOn = ldrIsDark;
          else if (ldrDarkAction == 3 && ldrIsDark && currentDir != DIR_STOP) stopMotors();
        }
        break;
      }
      case MODE_ACCEL: {
        if (millis() - lastPortReadTime >= 50) {
          lastPortReadTime = millis();
          float mAx = 0, mAy = 0, mAz = 0;
          bool readOk = false;
          if (modAccelType == 1) {
            Wire.beginTransmission(0x53); Wire.write(0x32);
            if (Wire.endTransmission() == 0 && Wire.requestFrom(0x53, 6) == 6) {
              mAx = (float)((int16_t)(Wire.read() | (Wire.read() << 8))) * 0.0383f;
              mAy = (float)((int16_t)(Wire.read() | (Wire.read() << 8))) * 0.0383f;
              mAz = (float)((int16_t)(Wire.read() | (Wire.read() << 8))) * 0.0383f;
              readOk = true;
            }
          }
          if (readOk) {
            float p = atan2(mAy, sqrt(mAx * mAx + mAz * mAz)) * 57.295779f;
            float r = atan2(-mAx, mAz) * 57.295779f;
            float t = atan2(sqrt(mAx * mAx + mAy * mAy), fabsf(mAz)) * 57.295779f;
            modPitch = p; modRoll = r; modTilt = t; modAx = mAx; modAy = mAy; modAz = mAz;
            latestReading = "Pitch:" + String(p, 0) + "° Roll:" + String(r, 0) + "° Tilt:" + String(t, 0) + "°";
            modTiltAlertActive = (t >= modTiltThreshold);
            if (modTiltAlertActive && modAccelAction == 1 && currentDir != DIR_STOP) stopMotors();
          }
        }
        break;
      }
      default: break;
    }
  }

  if (obstacleAction == 0 && !autoBrakeEnabled && obstacleState != NORMAL) { obstacleState = NORMAL; stopMotors(); }
  delay(2);
}